module.exports = {
    JWT_SECRET: "sahilsecret1"
}